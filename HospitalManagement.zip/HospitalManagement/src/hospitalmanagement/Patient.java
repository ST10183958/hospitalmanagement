/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagement;

/**
 *
 * @author kuri
 */
public class Patient extends Person {
    int MedicalRecordNumber;
    String PatientAilments;
    
    public Patient(String FirstName,String LastName,String StreetAddress,int Zipcode,int PhoneNumber,int MedicalRecordNumber, String PatientAilments) {
        super(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber);
    }
    
}
