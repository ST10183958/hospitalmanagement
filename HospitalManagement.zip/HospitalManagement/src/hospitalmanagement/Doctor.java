/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagement;

/**
 *
 * @author kuri
 */
public class Doctor extends HospitalStaff {
    boolean IsSpecialist;
    
    public Doctor(String FirstName, String LastName, String StreetAddress, int Zipcode, int PhoneNumber,String StaffID,int Salary,boolean IsSpecialist) {
        super(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber,StaffID,Salary);
        
        this.IsSpecialist = IsSpecialist;
    }
    
}
