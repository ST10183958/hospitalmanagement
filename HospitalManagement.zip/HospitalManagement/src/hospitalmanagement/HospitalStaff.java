/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagement;

/**
 *
 * @author kuri
 */
public class HospitalStaff extends Person {
    
    String StaffID;
    int Salary;
    public HospitalStaff(String FirstName, String LastName, String StreetAddress, int Zipcode, int PhoneNumber,String StaffID,int Salary) {
        super(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber);
        //System.out.println(FirstName+LastName+StreetAddress+Zipcode+PhoneNumber+StaffID);
        this.Salary = Salary;
    }

}
