/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagement;

/**
 *
 * @author kuri
 */
public class Person {
    String FirstName;
    String LastName;
    String StreetAddress;
    int Zipcode;
    int PhoneNumber;
    
    public Person(String FirstName,String LastName,String StreetAddress,int Zipcode,int PhoneNumber) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.StreetAddress = StreetAddress;
        this.Zipcode = Zipcode;
        this.PhoneNumber = PhoneNumber;
        
        System.out.println("Name:"+FirstName+"Surname:"+LastName+"Street Address:"+StreetAddress+"Zip code:"+Zipcode+"Phone number:"+PhoneNumber);
    }
}
