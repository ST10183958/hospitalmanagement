/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalmanagement;
import java.util.Scanner;

public class HospitalManagement {


    public static void main(String[] args) {

        String[] HospitalStaffArray = {};
        String[] DoctorArrays = {};
        String[] PatientArray = {};
        
        do {
            Scanner PersonDataScanner = new Scanner(System.in); 
            System.out.println("H: HospitalStaff");
            System.out.println("D: Doctor");
            System.out.println("P: Patient");
            System.out.println("Q: Quit");
            System.out.print("Option:");
            String PersonDataInput = PersonDataScanner.nextLine(); 

            if(PersonDataInput.equals("H")) {
                AddHospitalStaff(PersonDataScanner);
            }
            if(PersonDataInput.equals("D")) {
                AddDoctor(PersonDataScanner);
            }
            if(PersonDataInput.equals("P")) {
                AddPatient(PersonDataScanner);
            }
            if(PersonDataInput.equals("Q")) {
                System.exit(0);
            }    

        } while (true); 


    }
    
    public static void AddHospitalStaff(Scanner PersonDataInput) {
        //String FirstName, String LastName, String StreetAddress, int Zipcode, int PhoneNumber,String StaffID,int Salary
        System.out.print("Enter Staff FirstName:");
        String FirstName = PersonDataInput.nextLine();
        
        System.out.print("Enter Staff LastName:");
        String LastName = PersonDataInput.nextLine();
        
        System.out.print("Enter Staff StreetAddress:");
        String StreetAddress = PersonDataInput.nextLine();
        
        System.out.print("Enter Staff Zipcode:");
        int Zipcode = PersonDataInput.nextInt();
        
        System.out.print("Enter Staff PhoneNumber:");
        int PhoneNumber = PersonDataInput.nextInt();
                
        System.out.print("Enter Staff StaffID:");
        String StaffID = PersonDataInput.nextLine();
        
        System.out.println("\n");
        
        
        System.out.print("Enter Staff Salary:");
        int Salary = PersonDataInput.nextInt();
        
        HospitalStaff staff = new HospitalStaff(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber,StaffID,Salary);
        System.out.println("--------Output--------");
        System.out.println(staff.FirstName);
        System.out.println(staff.LastName);
        System.out.println(staff.StreetAddress);
        System.out.println(staff.Zipcode);
        System.out.println(staff.PhoneNumber);
        System.out.println(staff.StaffID);
        System.out.println(staff.Salary);
        System.out.println("------------------");
        System.out.println("\n");
    }
    
    public static void AddDoctor(Scanner PersonDataInput) {
        
        System.out.print("Enter Doctors FirstName:");
        String FirstName = PersonDataInput.nextLine();
        
        System.out.print("Enter Doctors LastName:");
        String LastName = PersonDataInput.nextLine();
        
        System.out.print("Enter Doctors StreetAddress:");
        String StreetAddress = PersonDataInput.nextLine();
        
        System.out.print("Enter Doctors Zipcode:");
        int Zipcode = PersonDataInput.nextInt();
        
        System.out.print("Enter Doctors PhoneNumber:");
        int PhoneNumber = PersonDataInput.nextInt();
                
        System.out.print("Enter Doctors StaffID:");
        String StaffID = PersonDataInput.nextLine();
        System.out.println("\n");
        System.out.print("Enter Doctors Salary:");
        int Salary = PersonDataInput.nextInt();
        
        System.out.print("Specialist True or False:");
        boolean IsSpecialist = PersonDataInput.nextBoolean();
        
        
        Doctor doctor = new Doctor(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber,StaffID,Salary,IsSpecialist);
        System.out.println("--------Output--------");
        System.out.println(doctor.FirstName);
        System.out.println(doctor.LastName);
        System.out.println(doctor.StreetAddress);
        System.out.println(doctor.Zipcode);
        System.out.println(doctor.PhoneNumber);
        System.out.println(doctor.StaffID);
        System.out.println(doctor.Salary);
        System.out.println(doctor.IsSpecialist);
        System.out.println("------------------");
        System.out.println("\n");
        
    }
    
    public static void AddPatient(Scanner PersonDataInput) {
        System.out.print("Enter Patient FirstName:");
        String FirstName = PersonDataInput.nextLine();
        
        System.out.print("Enter Patient LastName:");
        String LastName = PersonDataInput.nextLine();
        
        System.out.print("Enter Patient StreetAddress:");
        String StreetAddress = PersonDataInput.nextLine();
        
        System.out.print("Enter Patient Zipcode:");
        int Zipcode = PersonDataInput.nextInt();
        
        System.out.print("Enter Patient PhoneNumber:");
        int PhoneNumber = PersonDataInput.nextInt();
        
        System.out.print("Enter Patient MedicalRecordNumber:");
        int MedicalRecordNumber = PersonDataInput.nextInt();
        
        System.out.print("Enter Patient PatientAilments:");
        String PatientAilments = PersonDataInput.nextLine();
        
        Patient patient = new Patient(FirstName,LastName,StreetAddress,Zipcode,PhoneNumber,MedicalRecordNumber,PatientAilments);
        
        System.out.println("--------Output--------");
        System.out.println(patient.FirstName);
        System.out.println(patient.LastName);
        System.out.println(patient.StreetAddress);
        System.out.println(patient.Zipcode);
        System.out.println(patient.PhoneNumber);
        System.out.println(patient.MedicalRecordNumber);
        System.out.println(patient.PatientAilments);
        System.out.println("------------------");
        System.out.println("\n");
    }
   
}
